#!/usr/bin/env python3
import sys, requests, xmltodict, urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE = "https://192.168.1.100"
USER = "api11"
PASS = "Au10tication"

LOGIN_URLS = ("/nbi/login", "/nbi/login/")
CTYPES = ("application/xml", "text/xml")

def mk_session():
    s = requests.Session()
    s.verify = False
    s.trust_env = False
    s.proxies = {"http": None, "https": None}
    s.headers.update({"User-Agent":"curl/8.5.0","Accept":"application/xml"})
    return s

def post_raw(sess, url, data, ctype):
    r = sess.post(url, data=data, headers={"Content-Type": ctype}, timeout=30, allow_redirects=False)
    return r.status_code, r.text

def parse_xml(text):
    try: return xmltodict.parse(text)
    except Exception: return None

def login(sess):
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<csm:loginRequest xmlns:csm="csm">
  <protVersion>1.0</protVersion><reqId>1</reqId>
  <username>{USER}</username><password>{PASS}</password>
  <heartbeatRequested>false</heartbeatRequested>
</csm:loginRequest>"""
    last = None
    for path in LOGIN_URLS:
        for ct in CTYPES:
            code, body = post_raw(sess, f"{BASE}{path}", xml, ct)
            data = parse_xml(body) or {}
            resp = next((v for k,v in data.items() if "loginResponse" in k), None)
            if resp is not None:
                if resp.get("error"):
                    e = resp["error"]; raise SystemExit(f"Login-Fehler {e.get('code')}: {e.get('description')}")
                return body
            last = (code, body)
    raise SystemExit("Login fehlgeschlagen")

def get_devices(sess):
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<csm:deviceListByCapabilityRequest xmlns:csm="csm">
  <protVersion>1.0</protVersion><reqId>2</reqId>
  <deviceCapability>*</deviceCapability>
</csm:deviceListByCapabilityRequest>"""
    _, body = post_raw(sess, f"{BASE}/nbi/configservice/getDeviceListByType", xml, "application/xml")
    data = parse_xml(body) or {}
    node = next((v for k,v in data.items() if "deviceListResponse" in k), None)
    items = [] if not node else node.get("deviceId") or []
    if isinstance(items, dict): items = [items]
    return [{"name": it.get("deviceName"),
             "ip": it.get("ipv4Address") or it.get("ipv6Address"),
             "capability": it.get("deviceCapability"),
             "gid": it.get("gid")} for it in items]

def logout(sess):
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<csm:logoutRequest xmlns:csm="csm">
  <protVersion>1.0</protVersion><reqId>99</reqId>
</csm:logoutRequest>"""
    try: post_raw(sess, f"{BASE}/nbi/logout", xml, "application/xml")
    except Exception: pass

def main():
    s = mk_session()
    print("Login...")
    print(login(s))
    print("\nGeräte...")
    for d in get_devices(s):
        print(f"{d['name']}\t{d['ip']}\t{d['capability']}\t{d['gid']}")
    logout(s)

if __name__ == "__main__":
    try: main()
    except requests.HTTPError as e: print(f"HTTP-Fehler: {e}", file=sys.stderr); sys.exit(1)
    except Exception as e: print(f"Fehler: {e}", file=sys.stderr); sys.exit(1)
