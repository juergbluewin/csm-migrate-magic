# Heine NBI App – Kurzbeschreibung

Zweck: GUI- und CLI-Client für Cisco Security Manager (CSM) Northbound Interface (NBI) per HTTPS/XML. 
Funktion: Login, Geräteliste abrufen, Gerätekonfiguration per GID laden.
Voraussetzungen: Python 3.12+, Linux Mint/Ubuntu, Netzwerkzugriff auf CSM.
Sicherheitsstatus: Zertifikatsprüfung deaktiviert (nur Testnetze).

## Start (ohne Zertifikate)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# CLI: Geräteliste
python nbi_cli.py

# GUI
python heine_gui_nbi.py
```

## Konfiguration

IP und Zugangsdaten im Kopf der Dateien `nbi_cli.py` und `heine_gui_nbi.py` anpassen:

```python
BASE = "https://192.168.1.100"
USER = "api11"
PASS = "Au10tication"
```

## Hinweise

- Bei Fehlercode 29: Nur eine NB-API-Session pro Benutzer. 60–90 Sekunden warten oder Logout senden.
- Optional: `libgl1`, `libxcb-*` Runtimes installieren, falls Qt/xcb-Fehler auftreten.
