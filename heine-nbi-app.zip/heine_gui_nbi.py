#!/usr/bin/env python3
import sys, requests, xmltodict, urllib3
from PySide6.QtWidgets import QApplication, QMainWindow, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QPushButton, QTextEdit
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE = "https://192.168.1.100"
USER = "api11"
PASS = "Au10tication"

def mk_session():
    s = requests.Session(); s.verify=False; s.trust_env=False; s.proxies={"http":None,"https":None}
    s.headers.update({"User-Agent":"curl/8.5.0","Accept":"application/xml"})
    return s

def post(sess, url, xml):
    r = sess.post(url, data=xml.encode(), headers={"Content-Type":"application/xml"}, timeout=60, allow_redirects=False)
    return r.text

def login(sess):
    xml = f'''<?xml version="1.0" encoding="UTF-8"?><csm:loginRequest xmlns:csm="csm">
<protVersion>1.0</protVersion><reqId>1</reqId><username>{USER}</username><password>{PASS}</password><heartbeatRequested>false</heartbeatRequested></csm:loginRequest>'''
    return post(sess, f"{BASE}/nbi/login", xml)

def get_devices(sess):
    xml = '''<?xml version="1.0" encoding="UTF-8"?><csm:deviceListByCapabilityRequest xmlns:csm="csm">
<protVersion>1.0</protVersion><reqId>2</reqId><deviceCapability>*</deviceCapability></csm:deviceListByCapabilityRequest>'''
    data = xmltodict.parse(post(sess, f"{BASE}/nbi/configservice/getDeviceListByType", xml))
    node = next((v for k,v in data.items() if "deviceListResponse" in k), None)
    items = [] if not node else node.get("deviceId") or []
    if isinstance(items, dict): items=[items]
    return [{"name":i.get("deviceName"),"ip":i.get("ipv4Address") or i.get("ipv6Address"),"cap":i.get("deviceCapability"),"gid":i.get("gid")} for i in items]

def get_config(sess, gid):
    xml = f'''<?xml version="1.0" encoding="UTF-8"?><csm:deviceConfigByGIDRequest xmlns:csm="csm">
<protVersion>1.0</protVersion><reqId>3</reqId><gid>{gid}</gid></csm:deviceConfigByGIDRequest>'''
    return post(sess, f"{BASE}/nbi/configservice/getDeviceConfigByGID", xml)

def logout(sess):
    xml='''<?xml version="1.0" encoding="UTF-8"?><csm:logoutRequest xmlns:csm="csm"><protVersion>1.0</protVersion><reqId>99</reqId></csm:logoutRequest>'''
    try: post(sess, f"{BASE}/nbi/logout", xml)
    except Exception: pass

class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Heine CSM NBI Viewer")
        self.sess = mk_session()
        login(self.sess)
        w=QWidget(); self.setCentralWidget(w)
        self.table=QTableWidget(); self.table.setColumnCount(4); self.table.setHorizontalHeaderLabels(["Name","IP","Capability","GID"])
        self.out=QTextEdit(); self.out.setReadOnly(True)
        btn=QPushButton("Config laden")
        lay=QVBoxLayout(w); lay.addWidget(self.table); lay.addWidget(btn); lay.addWidget(self.out)
        btn.clicked.connect(self.fetch_config)
        self.load_devices()

    def load_devices(self):
        devs=get_devices(self.sess)
        self.table.setRowCount(len(devs))
        for r,d in enumerate(devs):
            self.table.setItem(r,0,QTableWidgetItem(d["name"] or ""))
            self.table.setItem(r,1,QTableWidgetItem(d["ip"] or ""))
            self.table.setItem(r,2,QTableWidgetItem(d["cap"] or ""))
            self.table.setItem(r,3,QTableWidgetItem(d["gid"] or ""))

    def fetch_config(self):
        row=self.table.currentRow()
        if row<0: return
        gid=self.table.item(row,3).text()
        xml=get_config(self.sess, gid)
        self.out.setPlainText(xml[:200000])

    def closeEvent(self, e):
        logout(self.sess); super().closeEvent(e)

if __name__=="__main__":
    app=QApplication(sys.argv); m=Main(); m.resize(1000,700); m.show(); sys.exit(app.exec())
